#ifndef CONFPARSE_H
#define CONFPARSE_H

#include "defs.h"
#include "conf.h"
#include "xconfig.h"

status_e cnf_get(struct configuration *confp);

#endif

