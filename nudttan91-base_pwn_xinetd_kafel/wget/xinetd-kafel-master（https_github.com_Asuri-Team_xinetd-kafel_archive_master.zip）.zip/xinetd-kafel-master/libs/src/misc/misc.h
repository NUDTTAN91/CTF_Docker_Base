/*
 * (c) Copyright 1992 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */


#ifndef __MISC_H
#define __MISC_H

/*
 * $Id$
 */

#if !defined(linux)
char *basename ( char *pathname ) ;
#endif

#endif 	/* __MISC_H */
